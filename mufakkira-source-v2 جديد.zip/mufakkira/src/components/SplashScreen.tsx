import { useEffect, useState } from "react";
import icon from "@/assets/splash-icon.jpg";

export function SplashScreen() {
  const [phase, setPhase] = useState<"show" | "hide" | "gone">("show");
  useEffect(() => {
    const t1 = setTimeout(() => setPhase("hide"), 2200);
    const t2 = setTimeout(() => setPhase("gone"), 2900);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);
  if (phase === "gone") return null;
  return (
    <div
      className={`splash fixed inset-0 z-50 flex flex-col items-center justify-center transition-opacity duration-700 ${
        phase === "hide" ? "pointer-events-none opacity-0" : "opacity-100"
      }`}
      onClick={() => setPhase("hide")}
    >
      <div className="splash-ring relative">
        <img src={icon} alt="" width={176} height={176} className="splash-icon h-44 w-44 rounded-[2.5rem]" />
      </div>
      <h1 className="splash-title font-display mt-10 text-5xl text-gold">مُفكِّرة الحفظ</h1>
      <p className="splash-sub mt-3 text-muted-foreground">اكتب · كرّر · اتقن</p>
      <div className="mt-10 h-1 w-40 overflow-hidden rounded-full bg-muted">
        <div className="splash-bar bg-gold h-full rounded-full" />
      </div>
    </div>
  );
}
