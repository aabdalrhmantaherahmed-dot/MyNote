import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useRef, useState, type ReactNode } from "react";
import { BookOpen, PenLine, Trophy, Sparkles, Trash2, Check, X, RotateCcw } from "lucide-react";
import { generateSentences } from "@/lib/sentences.functions";
import { SplashScreen } from "@/components/SplashScreen";
import {
  LINES_REQUIRED,
  WORD_TYPES,
  loadWords,
  saveWords,
  typeOf,
  useWords,
  type SavedWord,
  type WordType,
} from "@/lib/words-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "مُفكِّرة الحفظ — احفظ كلماتك بالكتابة والأمثلة" },
      { name: "description", content: "اكتب الكلمة 50 مرة، تعلّمها في جمل، راجعها واختبر نفسك." },
      { property: "og:title", content: "مُفكِّرة الحفظ" },
      { property: "og:description", content: "اكتب الكلمة 50 مرة، تعلّمها في جمل، راجعها واختبر نفسك." },
    ],
  }),
  component: Index,
});

type Tab = "write" | "saved" | "quiz";

function Index() {
  const [tab, setTab] = useState<Tab>("write");
  const words = useWords();
  const tabs: { id: Tab; label: string; icon: typeof PenLine }[] = [
    { id: "write", label: "كتابة كلمة", icon: PenLine },
    { id: "saved", label: `كلماتي (${words.length})`, icon: BookOpen },
    { id: "quiz", label: "اختبارات", icon: Trophy },
  ];
  return (
    <div className="mx-auto max-w-5xl px-6 py-10">
      <SplashScreen />
      <header className="mb-10 flex flex-wrap items-center justify-between gap-6">
        <div>
          <h1 className="font-display text-5xl text-gold">مُفكِّرة الحفظ</h1>
          <p className="mt-2 text-muted-foreground">اكتب، كرّر، افهم في سياق، ثم اختبر نفسك.</p>
        </div>
        <nav className="glass flex gap-1 rounded-2xl p-1.5">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-all ${
                tab === t.id ? "bg-gold text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <t.icon className="h-4 w-4" />
              {t.label}
            </button>
          ))}
        </nav>
      </header>
      <main className="animate-in fade-in slide-in-from-bottom-2 duration-500" key={tab}>
        {tab === "write" && <WriteTab onDone={() => setTab("saved")} />}
        {tab === "saved" && <SavedTab words={words} />}
        {tab === "quiz" && <QuizSection words={words} />}
      </main>
    </div>
  );
}

const norm = (s: string) => s.trim().toLowerCase();

type WordInfo = { type: WordType; meaning: string; sentences: string[] };

function WriteTab({ onDone }: { onDone: () => void }) {
  const [word, setWord] = useState("");
  const [locked, setLocked] = useState("");
  const [lines, setLines] = useState<string[]>([]);
  const [info, setInfo] = useState<WordInfo | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const token = useRef(0);

  const correct = lines.filter((l) => norm(l) === norm(locked)).length;
  const done = correct >= LINES_REQUIRED;

  const persist = (w: string, data: WordInfo) => {
    const all = loadWords();
    const prev = all.find((x) => norm(x.word) === norm(w));
    const entry: SavedWord = {
      id: prev?.id ?? crypto.randomUUID(),
      word: w,
      type: data.type,
      meaning: data.meaning,
      sentences: data.sentences,
      createdAt: prev?.createdAt ?? Date.now(),
      correct: prev?.correct ?? 0,
      wrong: prev?.wrong ?? 0,
    };
    saveWords([entry, ...all.filter((x) => x.id !== entry.id)]);
  };

  const analyze = async (w: string) => {
    const t = ++token.current;
    setLoading(true);
    setError("");
    try {
      const r = await generateSentences({ data: { word: w } });
      if (t !== token.current) return;
      setInfo(r);
      persist(w, r);
    } catch (e) {
      if (t !== token.current) return;
      setError(e instanceof Error ? e.message : "تعذر فحص الكلمة");
    } finally {
      if (t === token.current) setLoading(false);
    }
  };

  const start = () => {
    const w = word.trim();
    if (!w) return;
    setLocked(w);
    setLines(Array(LINES_REQUIRED).fill(""));
    setInfo(null);
    void analyze(w);
  };

  const changeType = (type: WordType) => {
    if (!info) return;
    const next = { ...info, type };
    setInfo(next);
    persist(locked, next);
  };

  const reset = () => {
    token.current++;
    setWord("");
    setLocked("");
    setLines([]);
    setInfo(null);
    setLoading(false);
    setError("");
  };

  if (!locked)
    return (
      <section className="glass mx-auto max-w-xl rounded-3xl p-10 text-center">
        <Sparkles className="mx-auto mb-4 h-10 w-10 text-primary" />
        <h2 className="font-display text-2xl">ما الكلمة التي تريد حفظها؟</h2>
        <input
          value={word}
          onChange={(e) => setWord(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && start()}
          placeholder="اكتب الكلمة هنا…"
          dir="auto"
          className="mt-6 w-full rounded-2xl border border-input bg-background/50 px-5 py-4 text-center text-2xl outline-none focus:ring-2 focus:ring-ring"
        />
        <button
          onClick={start}
          disabled={!word.trim()}
          className="bg-gold mt-6 w-full rounded-2xl py-4 font-bold text-primary-foreground transition hover:scale-[1.01] disabled:opacity-40"
        >
          ابدأ التدريب — {LINES_REQUIRED} سطراً
        </button>
        <p className="mt-4 text-sm text-muted-foreground">سنفحص الكلمة ونحفظها تلقائياً مع معناها وأمثلتها.</p>
      </section>
    );

  const typeLabel = info ? WORD_TYPES.find((t) => t.id === info.type)?.label : "";

  return (
    <section className="space-y-6">
      <div className="glass sticky top-4 z-10 flex flex-wrap items-center justify-between gap-4 rounded-2xl p-5">
        <div>
          <span className="text-sm text-muted-foreground">الكلمة</span>
          <div className="font-display text-3xl text-gold" dir="auto">{locked}</div>
          <div className="mt-1 text-xs">
            {loading && <span className="animate-pulse text-accent">جارٍ فحص الكلمة وحفظها…</span>}
            {!loading && info && <span className="text-success">✓ تم الحفظ تلقائياً · {typeLabel}</span>}
            {!loading && error && (
              <span className="text-destructive">
                {error} ·{" "}
                <button onClick={() => analyze(locked)} className="underline">إعادة المحاولة</button>
              </span>
            )}
          </div>
        </div>
        <div className="min-w-56 flex-1">
          <div className="mb-2 flex justify-between text-sm">
            <span className="text-muted-foreground">التقدّم</span>
            <span className="font-bold">{correct} من {LINES_REQUIRED}</span>
          </div>
          <div className="h-2.5 overflow-hidden rounded-full bg-muted">
            <div className="bg-gold h-full rounded-full transition-all duration-300" style={{ width: `${(correct / LINES_REQUIRED) * 100}%` }} />
          </div>
        </div>
        <button onClick={reset} className="rounded-xl border px-4 py-2 text-sm text-muted-foreground hover:text-foreground">
          كلمة أخرى
        </button>
      </div>

      {!done && (
        <div className="glass rounded-3xl p-8">
          <div className="grid gap-x-10 md:grid-cols-2">
            {lines.map((l, i) => {
              const ok = norm(l) === norm(locked);
              const bad = l.length > 0 && !norm(locked).startsWith(norm(l)) && !ok;
              return (
                <label key={i} className="notebook-line flex items-center gap-3 py-2">
                  <span className="w-7 text-xs text-muted-foreground">{i + 1}</span>
                  <input
                    value={l}
                    dir="auto"
                    autoFocus={i === 0}
                    onChange={(e) => {
                      const v = e.target.value;
                      setLines((p) => p.map((x, j) => (j === i ? v : x)));
                      if (norm(v) === norm(locked) && v.length >= locked.length) {
                        const next = e.currentTarget.closest(".grid")?.querySelectorAll("input")[i + 1] as HTMLInputElement | undefined;
                        next?.focus();
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        const next = e.currentTarget.closest(".grid")?.querySelectorAll("input")[i + 1] as HTMLInputElement | undefined;
                        next?.focus();
                      }
                    }}
                    className={`flex-1 bg-transparent py-1 text-xl outline-none ${ok ? "text-success" : bad ? "text-destructive" : ""}`}
                  />
                  {ok && <Check className="h-4 w-4 text-success" />}
                </label>
              );
            })}
          </div>
          <p className="mt-6 text-center text-muted-foreground">أكمل {LINES_REQUIRED - correct} سطراً بشكل صحيح لتظهر لك الكلمة في جمل.</p>
        </div>
      )}

      {done && (
        <div className="glass rounded-3xl p-8">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-display text-2xl text-gold">أحسنت! الكلمة في جمل 🎉</h3>
            <button
              onClick={() => analyze(locked)}
              disabled={loading}
              className="flex items-center gap-2 rounded-xl border px-4 py-2 text-sm text-muted-foreground hover:text-foreground disabled:opacity-50"
            >
              <Sparkles className="h-4 w-4" /> جمل جديدة
            </button>
          </div>
          {loading && <p className="mt-6 animate-pulse text-center text-accent">جارٍ تكوين الجمل…</p>}
          {error && !loading && <p className="mt-6 text-center text-destructive">{error}</p>}
          {info && (
            <>
              <div className="mt-6 flex flex-wrap items-center gap-2">
                <span className="text-sm text-muted-foreground">نوع الكلمة:</span>
                {WORD_TYPES.map((t) => (
                  <Chip key={t.id} active={info.type === t.id} onClick={() => changeType(t.id)}>
                    {t.label}
                  </Chip>
                ))}
              </div>
              {info.meaning && <p className="mt-4 text-lg text-muted-foreground">{info.meaning}</p>}
              <Sentences word={locked} sentences={info.sentences} />
            </>
          )}
          <div className="mt-8 flex gap-3">
            <button onClick={reset} className="bg-gold flex-1 rounded-2xl py-3 font-bold text-primary-foreground">كلمة جديدة</button>
            <button onClick={onDone} className="flex-1 rounded-2xl border py-3">إلى كلماتي</button>
          </div>
        </div>
      )}
    </section>
  );
}

function Highlight({ text, word }: { text: string; word: string }) {
  const idx = text.toLowerCase().indexOf(word.toLowerCase());
  if (idx < 0) return <>{text}</>;
  return (
    <>
      {text.slice(0, idx)}
      <mark className="rounded bg-primary/20 px-1 text-primary">{text.slice(idx, idx + word.length)}</mark>
      {text.slice(idx + word.length)}
    </>
  );
}

function Sentences({ word, sentences }: { word: string; sentences: string[] }) {
  return (
    <ol className="mt-6 space-y-3">
      {sentences.map((s, i) => (
        <li key={i} dir="auto" className="flex gap-4 rounded-2xl bg-secondary/60 p-4 text-lg">
          <span className="font-display text-accent">{i + 1}</span>
          <span><Highlight text={s} word={word} /></span>
        </li>
      ))}
    </ol>
  );
}

function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full border px-4 py-1.5 text-sm transition ${
        active ? "bg-gold border-transparent font-bold text-primary-foreground" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );
}

type Filter = "all" | WordType;

function TypeFilter({ words, value, onChange }: { words: SavedWord[]; value: Filter; onChange: (f: Filter) => void }) {
  return (
    <div className="mb-6 flex flex-wrap gap-2">
      <Chip active={value === "all"} onClick={() => onChange("all")}>الكل ({words.length})</Chip>
      {WORD_TYPES.map((t) => {
        const n = words.filter((w) => typeOf(w) === t.id).length;
        if (t.id === "other" && !n) return null;
        return (
          <Chip key={t.id} active={value === t.id} onClick={() => onChange(t.id)}>
            {t.plural} ({n})
          </Chip>
        );
      })}
    </div>
  );
}

const byFilter = (words: SavedWord[], f: Filter) => (f === "all" ? words : words.filter((w) => typeOf(w) === f));

function SavedTab({ words }: { words: SavedWord[] }) {
  const [open, setOpen] = useState<string | null>(null);
  const [practice, setPractice] = useState("");
  const [filter, setFilter] = useState<Filter>("all");
  if (!words.length) return <Empty text="لم تحفظ أي كلمة بعد. ابدأ من «كتابة كلمة»." />;
  const shown = byFilter(words, filter);
  const setType = (id: string, type: WordType) => saveWords(loadWords().map((x) => (x.id === id ? { ...x, type } : x)));
  return (
    <>
    <TypeFilter words={words} value={filter} onChange={setFilter} />
    {!shown.length && <Empty text="لا توجد كلمات في هذا القسم بعد." />}
    <div className="grid gap-4 md:grid-cols-2">
      {shown.map((w) => {
        const isOpen = open === w.id;
        return (
          <article key={w.id} className={`glass rounded-3xl p-6 transition ${isOpen ? "md:col-span-2" : ""}`}>
            <div className="flex items-start justify-between gap-4">
              <button onClick={() => { setOpen(isOpen ? null : w.id); setPractice(""); }} className="text-right">
                <div className="font-display text-3xl text-gold" dir="auto">{w.word}</div>
                <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{w.meaning}</p>
              </button>
              <button
                onClick={() => confirm("حذف هذه الكلمة؟") && saveWords(loadWords().filter((x) => x.id !== w.id))}
                className="text-muted-foreground hover:text-destructive"
                aria-label="حذف"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
              <select
                value={typeOf(w)}
                onChange={(e) => setType(w.id, e.target.value as WordType)}
                aria-label="نوع الكلمة"
                className="rounded-full border bg-secondary px-3 py-1 text-xs text-accent outline-none"
              >
                {WORD_TYPES.map((t) => (
                  <option key={t.id} value={t.id}>{t.label}</option>
                ))}
              </select>
              <span>{new Date(w.createdAt).toLocaleDateString("ar")}</span>
              <span className="text-success">✓ {w.correct}</span>
              <span className="text-destructive">✗ {w.wrong}</span>
            </div>
            {isOpen && (
              <div className="mt-6 animate-in fade-in">
                <p className="text-sm text-muted-foreground">راجع كتابتها مرة أخرى:</p>
                <input
                  value={practice}
                  onChange={(e) => setPractice(e.target.value)}
                  dir="auto"
                  placeholder="اكتب الكلمة…"
                  className={`notebook-line mt-2 w-full bg-transparent py-2 text-2xl outline-none ${
                    practice && (norm(practice) === norm(w.word) ? "text-success" : "")
                  }`}
                />
                <Sentences word={w.word} sentences={w.sentences} />
              </div>
            )}
          </article>
        );
      })}
    </div>
    </>
  );
}

function QuizSection({ words }: { words: SavedWord[] }) {
  const [filter, setFilter] = useState<Filter>("all");
  if (!words.length) return <Empty text="احفظ بعض الكلمات أولاً لتبدأ الاختبارات." />;
  const list = byFilter(words, filter);
  return (
    <>
      <div className="mx-auto max-w-2xl">
        <TypeFilter words={words} value={filter} onChange={setFilter} />
      </div>
      {list.length ? <QuizTab key={filter} words={list} /> : <Empty text="لا توجد كلمات في هذا القسم بعد." />}
    </>
  );
}

function Empty({ text }: { text: string }) {
  return <div className="glass rounded-3xl p-16 text-center text-muted-foreground">{text}</div>;
}

type Q = { word: SavedWord; kind: "fill" | "spell" | "meaning"; prompt: string; options?: string[] | undefined };

function shuffle<T>(a: T[]) {
  return [...a].sort(() => Math.random() - 0.5);
}

function buildQuiz(words: SavedWord[]): Q[] {
  return shuffle(words).slice(0, 10).map((w) => {
    const others = shuffle(words.filter((x) => x.id !== w.id)).slice(0, 3).map((x) => x.word);
    const withWord = w.sentences.filter((s) => s.toLowerCase().includes(w.word.toLowerCase()));
    const kinds: Q["kind"][] = ["spell"];
    if (withWord.length) kinds.push("fill");
    if (w.meaning && others.length) kinds.push("meaning");
    const kind = kinds[Math.floor(Math.random() * kinds.length)]!;
    if (kind === "fill") {
      const s = withWord[Math.floor(Math.random() * withWord.length)]!;
      const re = new RegExp(w.word.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
      return { word: w, kind, prompt: s.replace(re, "_____"), options: others.length ? shuffle([w.word, ...others]) : undefined };
    }
    if (kind === "meaning") return { word: w, kind, prompt: w.meaning, options: shuffle([w.word, ...others]) };
    return { word: w, kind, prompt: w.meaning || "اكتب الكلمة التي حفظتها" };
  });
}

function QuizTab({ words }: { words: SavedWord[] }) {
  const [seed, setSeed] = useState(0);
  const quiz = useMemo(() => buildQuiz(words), [seed, words.length]); // eslint-disable-line react-hooks/exhaustive-deps
  const [i, setI] = useState(0);
  const [score, setScore] = useState(0);
  const [answer, setAnswer] = useState("");
  const [shown, setShown] = useState<null | boolean>(null);

  if (!words.length) return <Empty text="احفظ بعض الكلمات أولاً لتبدأ الاختبارات." />;

  const restart = () => { setSeed((s) => s + 1); setI(0); setScore(0); setAnswer(""); setShown(null); };

  if (i >= quiz.length)
    return (
      <div className="glass mx-auto max-w-xl rounded-3xl p-12 text-center">
        <Trophy className="mx-auto h-14 w-14 text-primary" />
        <h2 className="font-display mt-4 text-4xl text-gold">{score} من {quiz.length}</h2>
        <p className="mt-2 text-muted-foreground">{score === quiz.length ? "ممتاز! حفظ كامل 🌟" : "استمر بالمراجعة وستتقن الجميع."}</p>
        <button onClick={restart} className="bg-gold mt-8 inline-flex items-center gap-2 rounded-2xl px-8 py-3 font-bold text-primary-foreground">
          <RotateCcw className="h-4 w-4" /> اختبار جديد
        </button>
      </div>
    );

  const q = quiz[i]!;
  const check = (val: string) => {
    if (shown !== null) return;
    const ok = norm(val) === norm(q.word.word);
    setAnswer(val);
    setShown(ok);
    if (ok) setScore((s) => s + 1);
    saveWords(loadWords().map((w) => (w.id === q.word.id ? { ...w, correct: w.correct + (ok ? 1 : 0), wrong: w.wrong + (ok ? 0 : 1) } : w)));
  };
  const next = () => { setI(i + 1); setAnswer(""); setShown(null); };
  const title = q.kind === "fill" ? "أكمل الجملة بالكلمة الصحيحة" : q.kind === "meaning" ? "ما الكلمة التي تحمل هذا المعنى؟" : "اكتب الكلمة بشكل صحيح";

  return (
    <div className="glass mx-auto max-w-2xl rounded-3xl p-10">
      <div className="mb-6 flex items-center justify-between text-sm text-muted-foreground">
        <span>سؤال {i + 1} من {quiz.length}</span>
        <span>النتيجة: {score}</span>
      </div>
      <div className="mb-8 h-1.5 overflow-hidden rounded-full bg-muted">
        <div className="bg-gold h-full transition-all" style={{ width: `${(i / quiz.length) * 100}%` }} />
      </div>
      <p className="text-sm text-accent">{title}</p>
      <p dir="auto" className="font-display mt-3 text-2xl leading-relaxed">{q.prompt}</p>

      {q.options ? (
        <div className="mt-8 grid gap-3 sm:grid-cols-2">
          {q.options.map((o) => {
            const isRight = norm(o) === norm(q.word.word);
            const state = shown === null ? "" : isRight ? "border-success text-success" : o === answer ? "border-destructive text-destructive" : "opacity-50";
            return (
              <button key={o} dir="auto" onClick={() => check(o)} className={`rounded-2xl border bg-secondary/50 px-5 py-4 text-lg transition hover:border-primary ${state}`}>
                {o}
              </button>
            );
          })}
        </div>
      ) : (
        <form className="mt-8 flex gap-3" onSubmit={(e) => { e.preventDefault(); check(answer); }}>
          <input
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            disabled={shown !== null}
            dir="auto"
            autoFocus
            placeholder="إجابتك…"
            className="flex-1 rounded-2xl border border-input bg-background/50 px-5 py-4 text-xl outline-none focus:ring-2 focus:ring-ring"
          />
          {shown === null && <button className="bg-gold rounded-2xl px-6 font-bold text-primary-foreground">تحقق</button>}
        </form>
      )}

      {shown !== null && (
        <div className="mt-6 flex items-center justify-between gap-4 animate-in fade-in">
          <span className={`flex items-center gap-2 text-lg ${shown ? "text-success" : "text-destructive"}`}>
            {shown ? <Check /> : <X />}
            {shown ? "إجابة صحيحة!" : <>الصحيح: <b dir="auto">{q.word.word}</b></>}
          </span>
          <button onClick={next} className="bg-gold rounded-2xl px-6 py-3 font-bold text-primary-foreground">التالي</button>
        </div>
      )}
    </div>
  );
}
