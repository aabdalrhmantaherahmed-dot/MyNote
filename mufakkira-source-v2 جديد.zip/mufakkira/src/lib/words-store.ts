import { useEffect, useState } from "react";

export type WordType = "noun" | "verb" | "adjective" | "other";

export const WORD_TYPES: { id: WordType; label: string; plural: string }[] = [
  { id: "noun", label: "اسم", plural: "الأسماء" },
  { id: "verb", label: "فعل", plural: "الأفعال" },
  { id: "adjective", label: "صفة", plural: "الصفات" },
  { id: "other", label: "أخرى", plural: "أخرى" },
];

export const typeOf = (w: { type?: WordType | undefined }): WordType => w.type ?? "other";

export type SavedWord = {
  id: string;
  word: string;
  type?: WordType | undefined;
  meaning: string;
  sentences: string[];
  createdAt: number;
  correct: number;
  wrong: number;
};

const KEY = "mufakkira-words-v1";
const EVT = "mufakkira-change";

export function loadWords(): SavedWord[] {
  try {
    return JSON.parse(localStorage.getItem(KEY) || "[]");
  } catch {
    return [];
  }
}

export function saveWords(words: SavedWord[]) {
  localStorage.setItem(KEY, JSON.stringify(words));
  window.dispatchEvent(new Event(EVT));
}

export function useWords() {
  const [words, setWords] = useState<SavedWord[]>([]);
  useEffect(() => {
    const sync = () => setWords(loadWords());
    sync();
    window.addEventListener(EVT, sync);
    window.addEventListener("storage", sync);
    return () => {
      window.removeEventListener(EVT, sync);
      window.removeEventListener("storage", sync);
    };
  }, []);
  return words;
}

export const LINES_REQUIRED = 50;
