import { createServerFn } from "@tanstack/react-start";

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["type", "meaning", "sentences"],
  properties: {
    type: { type: "string", enum: ["noun", "verb", "adjective", "other"] },
    meaning: { type: "string" },
    sentences: { type: "array", items: { type: "string" } },
  },
};

export const generateSentences = createServerFn({ method: "POST" })
  .inputValidator((d: { word: string }) => {
    const word = String(d?.word ?? "").trim().slice(0, 60);
    if (!word) throw new Error("word required");
    return { word };
  })
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("AI key missing");
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: {
        "Lovable-API-Key": key,
        Authorization: `Bearer ${key}`,
        "Content-Type": "application/json",
        "X-Lovable-AIG-SDK": "fetch",
      },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        stream: true,
        store: false,
        reasoning: { effort: "low" },
        instructions:
          'You help learners memorize words. "type": the part of speech of the word as written (noun, verb, adjective, or other). "meaning": a short Arabic explanation of the word. "sentences": exactly 6 varied, natural sentences in the SAME language as the word, each containing the word exactly as written.',
        input: data.word,
        text: { format: { type: "json_schema", name: "word_examples", strict: true, schema } },
      }),
    });
    if (res.status === 429) throw new Error("طلبات كثيرة، حاول بعد قليل");
    if (res.status === 402) throw new Error("نفد رصيد الذكاء الاصطناعي");
    if (!res.ok || !res.body) throw new Error("تعذر توليد الجمل");

    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "";
    let out = "";
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const p = line.slice(5).trim();
        if (!p || p === "[DONE]") continue;
        try {
          const ev = JSON.parse(p);
          if (ev.type === "response.output_text.delta") out += ev.delta ?? "";
        } catch {
          /* ignore */
        }
      }
    }
    const parsed = JSON.parse(out || '{"meaning":"","sentences":[]}');
    const types = ["noun", "verb", "adjective", "other"] as const;
    return {
      type: (types.includes(parsed.type) ? parsed.type : "other") as (typeof types)[number],
      meaning: String(parsed.meaning ?? ""),
      sentences: (parsed.sentences ?? []).map(String).slice(0, 8) as string[],
    };
  });
